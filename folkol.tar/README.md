# folkol.com homepage/dashboard

## Redeploy:

scp -r * folkol.com:/var/www/html/
